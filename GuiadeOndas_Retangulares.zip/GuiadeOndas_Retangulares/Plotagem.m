function Plotagem (eixos,larg,alt,modeD,modeV,viewD,velplot,freqq,chave,lamp)
    if strcmp(chave,'Plot')
        lamp.Color=[0 1 0];
        freqvalue=freqq*10^9;
    cont=1;
    a=larg*10^(-3);
    b=alt*10^(-3);
    c=3*10^8;
    nm=split(modeD,',');
    n=str2double(nm{1});
    m=str2double(nm{2});
    maxordem=max(n,m);
    beta_c=((n*pi/a)^2+(m*pi/b)^2)^(0.5);
    f_c=(beta_c*c)/(2*pi);
    %lambda_nm11=((2*a*b)/(n^2*b^2+m^2*a^2)^(0.5));
    lambda_0=c/freqvalue;
    lambda_g=lambda_0/((1-(f_c^2/freqvalue^2))^(0.5));
    %lambda_g11=3*a;
    %lambda_0111=sqrt(1/((1/lambda_g11^2)+(1/lambda_nm11^2)));
    %lambda_011=(lambda_g11/(1+(lambda_g11^2/lambda_nm11^2))^(0.5));
    beta_0=2*pi/lambda_0;
    %beta_011=2*pi/lambda_011;
    beta_nm=((beta_0^2)-(beta_c^2))^(0.5);
    %f_011=c/beta_011;
    if n==0 && m==0
        warning('O modo (00) � um modo n�o propagante. Por favor, selecione um modo dispon�vel')
    else
        if strcmp(modeV,'TE')
            if strcmp(viewD,'TopV')
                 if ~real(beta_nm)
                    lambda_g=3*a;
                 end
                 hold(eixos,'off')
                 y = b;     
                 x = linspace(0,a,20+4*maxordem-2);
                 z = linspace(0,3*lambda_g,20+4*maxordem-2);
                 [x,z] = meshgrid(x,z);  
                 t=0:(1/freqvalue)*10^(-2):10/freqvalue;
                 
                 for tempo=1:velplot:length(t)      
                 
                 E_x = real(1j*cos(n*pi.*x./a).*sin(m*pi.*y./b).*exp(1j*beta_nm*z)*exp(1j*2*pi*freqvalue*t(tempo)));    
                 E_z = real(zeros(size(real(E_x)))*exp(1j*2*pi*freqvalue*t(tempo)));
                 H_x = real(1j*sin(n*pi.*x./a).*cos(m*pi.*y./b).*exp(1j*beta_nm*z)*exp(1j*2*pi*freqvalue*t(tempo)));
                 H_z = real(cos(n*pi.*x./a).*cos(m*pi.*y./b).*exp(1j*beta_nm*z)*exp(1j*2*pi*freqvalue*t(tempo)));
                
                 quiver(eixos,z,x,H_z,H_x,'blue');
                 hold(eixos,'on')
                 quiver(eixos,z,x,E_z,E_x,'red');  
                 %legend(eixos,"Campo magn�tico","Campo el�trico");
                 xlim(eixos,[0 3*lambda_g]);
                 ylim(eixos,[0 a]);
                 x_lim=linspace(0,3*lambda_g,7);
                 y_lim=linspace(0,a,5);
                 x_limmm=x_lim*10^3;
                 y_limmm=y_lim*10^3;
                 strx_limmm=strsplit(num2str(x_limmm));
                 stry_limmm=strsplit(num2str(y_limmm));
                 xticks(eixos,x_lim);
                 yticks(eixos,y_lim);
                 set(eixos,'XTickLabel',strx_limmm);
                 set(eixos,'YTickLabel',stry_limmm);
                 xlabel(eixos,'Comprimento [mm]');
                 ylabel(eixos,'Largura [mm]');
                 cont=cont+1;
                 pause(.1);
                 hold(eixos,'off')
                 end
            elseif strcmp(viewD,'TransvV')
                hold(eixos,'off')
                x=linspace(0,a,20+4*maxordem-2);
                y=linspace(0,b,20+4*maxordem-2);
                [x,y]=meshgrid(x,y);
                t=0:(1/freqvalue)*10^(-2):10/freqvalue;
                max_cos=max(cos(2*pi*freqvalue*t));
                Ex_0=cos(n*pi.*x./a).*sin(m*pi.*y./b);
                Ey_0=-sin(n*pi.*x./a).*cos(m*pi.*y./b);
                Hx_0=sin(n*pi.*x./a).*cos(m*pi.*y./b);
                Hy_0=cos(n*pi.*x./a).*sin(m*pi.*y./b);
                Ex_max=max(max(abs(Ex_0)))*max_cos;
                Ey_max=max(max(abs(Ey_0)))*max_cos;
                Hx_max=max(max(abs(Hx_0)))*max_cos;
                Hy_max=max(max(abs(Hy_0)))*max_cos;
                if Ex_max==0
                    Ex_max=1;
                end
                if Ey_max==0
                    Ey_max=1;
                end
                if Hx_max==0
                    Hx_max=1;
                end
                if Hy_max==0
                    Hy_max=1;
                end
     
                    
                for tempo=1:velplot:length(t) 

                    E_x = Ex_0*a*real(exp(1j*2*pi*freqvalue*t(tempo)))./(Ex_max*20);       
                    E_y = Ey_0*b*real(exp(1j*2*pi*freqvalue*t(tempo)))./(Ey_max*20);
                    H_x = Hx_0*a*real(exp(1j*2*pi*freqvalue*t(tempo)))./(Hx_max*20);
                    H_y = Hy_0*b*real(exp(1j*2*pi*freqvalue*t(tempo)))./(Hy_max*20);
                    quiver(eixos,x,y,H_x,H_y,'blue','AutoScale','off');
                    hold(eixos,'on')
                    quiver(eixos,x,y,E_x,E_y,'red','AutoScale','off');
                    %legend(eixos,"Campo magn�tico","Campo el�trico");
                    xlim(eixos,[0 a]);
                    ylim(eixos,[0 b]);
                    x_lim=linspace(0,a,7);
                    y_lim=linspace(0,b,5);
                    x_limmm=x_lim*10^3;
                    y_limmm=y_lim*10^3;
                    strx_limmm=strsplit(num2str(x_limmm));
                    stry_limmm=strsplit(num2str(y_limmm));
                    xticks(eixos,x_lim);
                    yticks(eixos,y_lim);
                    set(eixos,'XTickLabel',strx_limmm);
                    set(eixos,'YTickLabel',stry_limmm);
                    xlabel(eixos,'Largura [mm]');
                    ylabel(eixos,'Altura [mm]');
                    pause(.1);
                    hold(eixos,'off')
                end
            else
                
                if ~real(beta_nm)
                    lambda_g=3*b;
                 end
                 hold(eixos,'off')
                 x = a;     
                 y = linspace(0,b,20+2*maxordem-2);
                 z = linspace(0,3*lambda_g,20+2*maxordem-2);
                 [y,z] = meshgrid(y,z);  
                 t=0:(1/freqvalue)*10^(-2):10/freqvalue;
                 
                 for tempo=1:velplot:length(t)      
                 
                 E_y = real(-sin(n*pi.*x./a).*cos(m*pi.*y./b).*exp(1j*beta_nm*z)*exp(1j*2*pi*freqvalue*t(tempo)));    
                 E_z = real(zeros(size(real(E_y)))*exp(1j*2*pi*freqvalue*t(tempo)));
                 H_y = real(1j*cos(n*pi.*x./a).*sin(m*pi.*y./b).*exp(1j*beta_nm*z)*exp(1j*2*pi*freqvalue*t(tempo)));
                 H_z = real(cos(n*pi.*x./a).*cos(m*pi.*y./b).*exp(1j*beta_nm*z)*exp(1j*2*pi*freqvalue*t(tempo)));
                
                 quiver(eixos,z,y,H_z,H_y,'blue');
                 hold(eixos,'on')
                 quiver(eixos,z,y,E_z,E_y,'red');  
                 %legend(eixos,"Campo magn�tico","Campo el�trico");
       
                 xlim(eixos,[0 3*lambda_g]);
                 ylim(eixos,[0 b]);
                 x_lim=linspace(0,3*lambda_g,7);
                 y_lim=linspace(0,b,5);
                 x_limmm=x_lim*10^3;
                 y_limmm=y_lim*10^3;
                 strx_limmm=strsplit(num2str(x_limmm));
                 stry_limmm=strsplit(num2str(y_limmm));
                 xticks(eixos,x_lim);
                 yticks(eixos,y_lim);
                 set(eixos,'XTickLabel',strx_limmm);
                 set(eixos,'YTickLabel',stry_limmm);
                 xlabel(eixos,'Comprimento [mm]');
                 ylabel(eixos,'Altura [mm]');
                 
                 pause(.1);
                 hold(eixos,'off')
                 end
            
            end
            
            
            
        elseif n>=1 && m>=1
            if strcmp(viewD,'TopV')
                 hold(eixos,'off')
                 if ~real(beta_nm)
                    lambda_g=3*a;
                 end
                 y = b;     
                 x = linspace(0,a,20+2*maxordem-2);
                 z = linspace(0,3*lambda_g,20+2*maxordem-2);
                 [x,z] = meshgrid(x,z);
                 t=0:(1/freqvalue)*10^(-2):10/freqvalue;
                for tempo=1:velplot:length(t) 
                    E_x=real(-1j*cos((n*pi*x)/a).*sin((m*pi*y)/b).*exp(1j*beta_nm*z)*exp(1j*2*pi*freqvalue*t(tempo)));
                    E_y=real(-1j*sin((n*pi*x)/a).*cos((m*pi*y)/b).*exp(1j*beta_nm*z)*exp(1j*2*pi*freqvalue*t(tempo)));
                    E_z=real(sin((n*pi*x)/a).*sin((m*pi*y)/b).*exp(1j*beta_nm.*z)*exp(1j*2*pi*freqvalue*t(tempo)));
                    H_x=real(-E_y);
                    quiver(eixos,z,x,zeros(length(H_x)),H_x,'blue');
                    hold(eixos,'on')
                    quiver(eixos,z,x,E_z,E_x,'red');
                    %legend(eixos,"Campo magn�tico","Campo el�trico");
                    xlim(eixos,[0 3*lambda_g]);
                    ylim(eixos,[0 a]);
                    x_lim=linspace(0,3*lambda_g,7);
                    y_lim=linspace(0,a,5);
                    x_limmm=x_lim*10^3;
                    y_limmm=y_lim*10^3;
                    strx_limmm=strsplit(num2str(x_limmm));
                    stry_limmm=strsplit(num2str(y_limmm));
                    xticks(eixos,x_lim);
                    yticks(eixos,y_lim);
                    set(eixos,'XTickLabel',strx_limmm);
                    set(eixos,'YTickLabel',stry_limmm);
                    xlabel(eixos,'Comprimento [mm]');
                    ylabel(eixos,'Largura [mm]');
                    pause(.1);
                    hold(eixos,'off')
                end
            elseif strcmp(viewD,'TransvV')
                hold(eixos,'off')
                x=linspace(0,a,20+2*maxordem-2);
                y=linspace(0,b,20+2*maxordem-2);
                [x,y]=meshgrid(x,y);
                t=0:(1/freqvalue)*10^(-2):10/freqvalue;
                max_cos=max(cos(2*pi*freqvalue*t));
                Ex_0=-cos(n*pi.*x./a).*sin(m*pi.*y./b);
                Ey_0=-sin(n*pi.*x./a).*cos(m*pi.*y./b);
                Hx_0=sin(n*pi.*x./a).*cos(m*pi.*y./b);
                Hy_0=cos(n*pi.*x./a).*sin(m*pi.*y./b);
                Ex_max=max(max(abs(Ex_0)))*max_cos;
                Ey_max=max(max(abs(Ey_0)))*max_cos;
                Hx_max=max(max(abs(Hx_0)))*max_cos;
                Hy_max=max(max(abs(Hy_0)))*max_cos;
                
                if Ex_max==0
                    Ex_max=1;
                end
                if Ey_max==0
                    Ey_max=1;
                end
                if Hx_max==0
                    Hx_max=1;
                end
                if Hy_max==0
                    Hy_max=1;
                end
     
                for tempo=1:velplot:length(t) 

                    E_x = Ex_0*a*real(exp(1j*2*pi*freqvalue*t(tempo)))./(Ex_max*20);       
                    E_y = Ey_0*b*real(exp(1j*2*pi*freqvalue*t(tempo)))./(Ey_max*20);
                    H_x = Hx_0*a*real(exp(1j*2*pi*freqvalue*t(tempo)))./(Hx_max*20);
                    H_y = Hy_0*b*real(exp(1j*2*pi*freqvalue*t(tempo)))./(Hy_max*20);
                    quiver(eixos,x,y,H_x,H_y,'blue','AutoScale','off');
                    hold(eixos,'on')
                    quiver(eixos,x,y,E_x,E_y,'red','AutoScale','off');
                    %legend(eixos,"Campo magn�tico","Campo el�trico");
                    xlim(eixos,[0 a]);
                    ylim(eixos,[0 b]);
                    x_lim=linspace(0,a,7);
                    y_lim=linspace(0,b,5);
                    x_limmm=x_lim*10^3;
                    y_limmm=y_lim*10^3;
                    strx_limmm=strsplit(num2str(x_limmm));
                    stry_limmm=strsplit(num2str(y_limmm));
                    xticks(eixos,x_lim);
                    yticks(eixos,y_lim);
                    set(eixos,'XTickLabel',strx_limmm);
                    set(eixos,'YTickLabel',stry_limmm);
                    xlabel(eixos,'Largura [mm]');
                    ylabel(eixos,'Altura [mm]');
                    pause(.1);
                    hold(eixos,'off')
                end
            else
              
                 if ~real(beta_nm)
                    lambda_g=3*b;
                 end
                 hold(eixos,'off')
                 x = a;     
                 y = linspace(0,b,20+2*maxordem-2);
                 z = linspace(0,3*lambda_g,20+2*maxordem-2);
                 [y,z] = meshgrid(y,z);  
                 t=0:(1/freqvalue)*10^(-2):10/freqvalue;
                 
                 for tempo=1:velplot:length(t)      
                 
                 E_y = real(-1j*sin(n*pi.*x./a).*cos(m*pi.*y./b).*exp(1j*beta_nm*z)*exp(1j*2*pi*freqvalue*t(tempo)));    
                 E_z = real(sin(n*pi.*x./a).*sin(m*pi.*y./b).*exp(1j*beta_nm*z)*exp(1j*2*pi*freqvalue*t(tempo)));
                 H_y = real(-1j*cos(n*pi.*x./a).*sin(m*pi.*y./b).*exp(1j*beta_nm*z)*exp(1j*2*pi*freqvalue*t(tempo)));
                 H_z = real(zeros(size(real(E_y)))*exp(1j*2*pi*freqvalue*t(tempo)));
                
                 quiver(eixos,z,y,H_z,H_y,'blue');
                 hold(eixos,'on')
                 quiver(eixos,z,y,E_z,E_y,'red');  
                 %legend(eixos,"Campo magn�tico","Campo el�trico");
       
                 xlim(eixos,[0 3*lambda_g]);
                 ylim(eixos,[0 b]);
                 x_lim=linspace(0,3*lambda_g,7);
                 y_lim=linspace(0,b,5);
                 x_limmm=x_lim*10^3;
                 y_limmm=y_lim*10^3;
                 strx_limmm=strsplit(num2str(x_limmm));
                 stry_limmm=strsplit(num2str(y_limmm));
                 xticks(eixos,x_lim);
                 yticks(eixos,y_lim);
                 set(eixos,'XTickLabel',strx_limmm);
                 set(eixos,'YTickLabel',stry_limmm);
                 xlabel(eixos,'Comprimento [mm]');
                 ylabel(eixos,'Altura [mm]');
                 
                 pause(.1);
                 hold(eixos,'off')
                 end
                
                
            end
        else
            warning('Os modos (X0) e (0X) s�o evanescentes para ondas transversais magn�ticas. Por favor, selecione um modo dispon�vel.')
        end
    end

        
    else
        lamp.Color=[1 0 0];
        cla(eixos,'reset')
        hold(eixos,'off')
        [x,y] = meshgrid(0:0.2:1,0:0.2:1);
        u = x.*0;
        v = y.*0;
        for el=1:0.001:100000
            quiver(eixos,x,y,u,v)
            xlabel(eixos,'');
            ylabel(eixos,'');
            pause(.1);
            hold(eixos,'off')
        end
    end
 
 
end
fig=uifigure;
fig.Position=[200 150 850 500];

ax = uiaxes(fig);
box(ax,'on')
ax.Position = [25 80 600 380];

axfig=uiaxes(fig);
axfig.Position= [25 2 70 70];
imshow('legenda.png','Parent',axfig);

leg1 = uilabel(fig);
leg1.Text = "- Campo Magn�tico";
leg1.Position = [90 40 200 20];

leg2 = uilabel(fig);
leg2.Text = "- Campo El�trico";
leg2.Position = [90 20 200 20];

larg = uilabel(fig);
larg.Text = "Largura do Guia de Onda (mm)";
larg.Position = [655 425 200 20];
largValue = uieditfield(fig,'numeric');
largValue.Position = [675 405 120 20];
largValue.Value=22.86;
alt = uilabel(fig);
alt.Text = "Altura do Guia de Onda (mm)";
alt.Position = [655 375 200 20];
altValue = uieditfield(fig,'numeric');
altValue.Position = [675 355 120 20];
altValue.Value=10.16;
typemode = uilabel(fig);
typemode.Text = "Tipo de Modo";
typemode.Position = [655 325 200 20];
modeDrop = uidropdown(fig);
modeDrop.Position = [675 305 120 20];
modeDrop.Items=["Transv. El�trica" "Transv. Magn�tica"];
modeDrop.ItemsData = ["TE" "TM"];
mode = uilabel(fig);
mode.Text = "Modo (n,m)";
mode.Position = [655 275 200 20];
modeValue = uieditfield(fig,'HorizontalAlignment','right');
modeValue.Position = [675 255 120 20];
viewmode = uilabel(fig);
viewmode.Text = "Vista";
viewmode.Position = [655 225 200 20];
viewDrop = uidropdown(fig);
viewDrop.Position = [675 205 120 20];
viewDrop.Items=["Vista Superior" "Vista Transversal" "Vista Lateral"];
viewDrop.ItemsData = ["TopV" "TransvV" "SideV"];
freq = uilabel(fig);
freq.Text = "Frequ�ncia (GHz)";
freq.Position = [655 175 200 20];
freqValue = uieditfield(fig,'numeric','HorizontalAlignment','right');
freqValue.Position = [675 155 120 20];
slider = uilabel(fig);
slider.Text = "Velocidade do Gr�fico";
slider.Position = [655 125 200 20];
sld = uislider(fig,'MajorTicks',[1 2 3 4 5 6 7 8 9 10],'ValueChangedFcn',@slider_callback);
sld.Position = [675 105 120 20];
sld.Limits = [1 10];
sld.Value = 1;
lmp = uilamp(fig,'Position',[800 10 20 20],'Color','red');
chave=uiswitch(fig,'rocker','Orientation','Horizontal','Position',[700 30 60 40],'Items',{'Plot','Reset'});
chave.Value='Reset';
chave.ValueChangedFcn=@(src,event) Plotagem(ax,largValue.Value, altValue.Value,modeValue.Value,modeDrop.Value,viewDrop.Value,sld.Value,freqValue.Value,chave.Value,lmp);